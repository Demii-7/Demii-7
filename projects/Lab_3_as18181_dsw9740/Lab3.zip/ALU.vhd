----------------------------------------------------------------------------------
-- Company:       NYU Abu Dhabi
-- Engineer:      Aman Sunesh, Demarce Williams
--
-- Create Date:   23/02/2025
-- Design Name:   ALU with Seven-Segment Display Interface
-- Module Name:   ALU - Behavioral
-- Project Name:  Advanced Digital Logic Lab 3 - ALU and Display
-- Target Device: 
-- Tool Versions: Xilinx 
-- Description: 
-- VHDL code for an Arithmetic Logic Unit (ALU) that performs various operations
-- on 4-bit two's complement numbers and outputs an 8-bit result. The ALU supports
-- addition, subtraction, bitwise AND, OR, rotate right, shift left logical, shift right
-- logical, and shift right arithmetic. Overflow detection is implemented for 
-- addition and subtraction. 
--
-- Dependencies: 
-- IEEE.STD_LOGIC_1164, IEEE.NUMERIC_STD
--
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ALU is
    Port ( a : in  STD_LOGIC_VECTOR (3 downto 0);
           b : in  STD_LOGIC_VECTOR (3 downto 0);
           sel : in  STD_LOGIC_VECTOR (2 downto 0);
           result : out  STD_LOGIC_VECTOR (7 downto 0);
			  overflow : out STD_LOGIC
			 );
end ALU;

architecture Behavioral of ALU is
	signal sum: signed(4 downto 0);
	signal diff: signed(4 downto 0);
	signal overflow_add: std_logic;
	signal overflow_sub: std_logic;
	
begin
-- Resize the 4-bit signed operands to 5 bits, then add/subtract.
sum  <= resize(signed(a), 5) + resize(signed(b), 5);
diff <= resize(signed(a), 5) - resize(signed(b), 5);

-- Process to detect overflow for addition
process(sum)
	variable sum_int : integer;
begin
	sum_int := to_integer(sum);
	if (sum_int > 7) or (sum_int < -8) then
		overflow_add <= '1';
	else
		overflow_add <= '0';
	end if;
end process;

-- Process to detect overflow for subtraction
process(diff)
	variable diff_int : integer;
begin
	diff_int := to_integer(diff);
	if (diff_int > 7) or (diff_int < -8) then
		overflow_sub <= '1';
	else
		overflow_sub <= '0';
	end if;
end process;


-- Select which overflow flag to output based on the operation.
process(sel, overflow_add, overflow_sub)
begin
  case sel is
		when "000" =>  -- Addition
			 overflow <= overflow_add;
		when "001" =>  -- Subtraction
			 overflow <= overflow_sub;
		when others =>
			 overflow <= '0';
  end case;
end process;

-- For addition and subtraction, we output the 5-bit result resized to 8 bits.
with sel select 
	result <=
		std_logic_vector(resize(sum, 8))                                     when "000",  -- Addition
		std_logic_vector(resize(diff, 8))                                    when "001",  -- Subtraction: a + (-b)
		std_logic_vector(a and b)                                            when "010",  -- Bitwise AND
		std_logic_vector(a or b)                                             when "011",  -- Bitwise OR
		std_logic_vector(unsigned(a) ror to_integer(unsigned(b)))            when "100",  -- Rotate Right
		std_logic_vector(unsigned(a) sll to_integer(unsigned(b)))            when "101",  -- Shift Left Logical
		std_logic_vector(unsigned(a) srl to_integer(unsigned(b)))            when "110",  -- Shift Right Logical
		std_logic_vector(shift_right(signed(a), to_integer(unsigned(b))))    when "111",  -- Shift Right Arithmetic
	   (others => 'X')                                                      when others; -- Default Case
end Behavioral;

