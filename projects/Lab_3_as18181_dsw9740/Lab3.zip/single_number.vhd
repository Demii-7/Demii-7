----------------------------------------------------------------------------------
-- Company:       NYU Abu Dhabi
-- Engineer:      Aman Sunesh, Demarce Williams
--
-- Create Date:   23/02/2025
-- Design Name:   Seven-Segment Display Digit Decoder
-- Module Name:   single_number - Behavioral
-- Project Name:  Advanced Digital Logic Lab 3 - ALU and Display
-- Target Device: 
-- Tool Versions: Xilinx 
-- Description: 
-- VHDL code for a digit decoder that drives a single seven-segment display.
-- The module receives a 4-bit two's complement number as input and outputs
-- the corresponding seven-segment code for that number. In addition, an overflow 
-- flag and an overflow digit control input are used to display an "F"
-- (for overflow).
--
-- Dependencies: 
-- IEEE.STD_LOGIC_1164 for basic logic types.
--
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity single_number is
    Port ( number : in  STD_LOGIC_VECTOR (3 downto 0);
			  overflow: in STD_LOGIC;
			  is_overflow_digit: in  STD_LOGIC;  -- to have the display go blank when overflow = 0
           seg : out  STD_LOGIC_VECTOR (0 to 7)
			  );
end single_number;

architecture Behavioral of single_number is
begin
	process(overflow, is_overflow_digit, number)
	begin
		if is_overflow_digit = '1' then
			if overflow = '1' then
				seg <= "01110001";  -- Pattern for F (Overflow)
			else
				seg <= "11111111";  -- Blank when no overflow on dedicated overflow digit
			end if;
		else  -- for normal output digit
			if overflow = '1' then
				seg <= "11111111";  -- Blank when overflow occurs
			else
				case number is
					when "0000" => seg <= "00000011"; -- 0
					when "0001" => seg <= "10011111"; -- 1 
					when "0010" => seg <= "00100101"; -- 2
					when "0011" => seg <= "00001101"; -- 3
					when "0100" => seg <= "10011001"; -- 4
					when "0101" => seg <= "01001001"; -- 5
					when "0110" => seg <= "01000001"; -- 6
					when "0111" => seg <= "00011111"; -- 7
					when "1000" => seg <= "00000000"; -- -8
					when "1001" => seg <= "00011110"; -- -7
					when "1010" => seg <= "01000000"; -- -6
					when "1011" => seg <= "01001000"; -- -5
					when "1100" => seg <= "10011000"; -- -4
					when "1101" => seg <= "00001100"; -- -3
					when "1110" => seg <= "00100100"; -- -2
					when "1111" => seg <= "10011110"; -- -1
					when others => seg <= "11111111"; -- all off
				end case;
			end if;
		end if;
	end process;
end Behavioral;

