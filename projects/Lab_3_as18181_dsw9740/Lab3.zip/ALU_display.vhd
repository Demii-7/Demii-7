----------------------------------------------------------------------------------
-- Company:       NYU Abu Dhabi
-- Engineer:      Aman Sunesh, Demarce Williams
--
-- Create Date:   23/02/2025
-- Design Name:   ALU Display Controller for FPGA
-- Module Name:   ALU_display - Behavioral
-- Project Name:  Advanced Digital Logic Lab 3 - ALU and Display
-- Target Device: 
-- Tool Versions: Xilinx 
-- Description: 
-- VHDL top-level module that integrates the ALU and single_number modules to display
-- the ALU inputs (PI_a and PI_b) and ALU result on a multiplexed 4-digit seven-segment
-- display. The leftmost two digits display PI_a and PI_b, the next digit shows the 
-- overflow indicator (if any), and the rightmost digit shows the ALU result.
--
-- Dependencies:
-- ALU, single_number modules.
--
-- Additional Comments:
--
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


-- Entity declaration
entity ALU_display is
    Port ( 
	     clk    : in STD_LOGIC;
		  PI_a   : in  STD_LOGIC_VECTOR (3 downto 0);
        PI_b   : in  STD_LOGIC_VECTOR (3 downto 0);
        PI_sel : in  STD_LOGIC_VECTOR (2 downto 0);
        PO_seg : out  STD_LOGIC_VECTOR (0 to 7);			  
        PO_an  : out  STD_LOGIC_VECTOR (3 downto 0));			  
end ALU_display;


-- Architecture declaration
architecture Behavioral of ALU_display is

-- Declare components
component ALU is
 Port (
	a        : in  STD_LOGIC_VECTOR (3 downto 0);
	b        : in  STD_LOGIC_VECTOR (3 downto 0);
	sel      : in  STD_LOGIC_VECTOR (2 downto 0);
	result   : out STD_LOGIC_VECTOR (7 downto 0);
	overflow : out STD_LOGIC
	);
end component;

component single_number is
 Port (
	number             : in  STD_LOGIC_VECTOR (3 downto 0);
	overflow           : in STD_LOGIC;   -- When '1', display "F"
	is_overflow_digit  : in  STD_LOGIC;
	seg                : out STD_LOGIC_VECTOR (0 to 7)
 );
end component;


-- clock divider signals
--
constant cnt_max              : integer := 100000;
signal clk_cnt                : integer range 0 to cnt_max;
signal seg_mode, seg_mode_new : integer range 0 to 3;

-- ALU output 
signal ALU_out : STD_LOGIC_VECTOR(7 downto 0);
signal ovf     : STD_LOGIC;   -- ALU Overflow Flag

-- The 7-segment patterns for each 4 bit value
signal seg_a        : STD_LOGIC_VECTOR(0 to 7);
signal seg_b        : STD_LOGIC_VECTOR(0 to 7);
signal seg_result   : STD_LOGIC_VECTOR(0 to 7);
signal seg_overflow : STD_LOGIC_VECTOR(0 to 7);   -- Pattern for overflow indicator

begin

ALU_ins: ALU
	port map (
		a        => PI_a,
		b        => PI_b,
		sel      => PI_sel,
		result   => ALU_out,
		overflow => ovf
	);

-- Display the 4-bit input PI_a on the leftmost digit.
SINGLE_A: single_number
	port map (
		number            => PI_a,
		overflow          => '0',    -- No overflow indicator for PI_a
		is_overflow_digit => '0',
		seg               => seg_a
		);

-- Display the 4-bit input PI_b on the second digit.
SINGLE_B: single_number
	port map (
		number            => PI_b,
		overflow          => '0',    -- No overflow indicator for PI_b
		is_overflow_digit => '0',
		seg               => seg_b
		);
		
-- Display the lower 4 bits of the ALU result on the rightmost digit.
SINGLE_ALU_OUT: single_number
	port map (
		number            => ALU_out(3 downto 0),
		overflow          => ovf,    -- No overflow indicator for PI_a, we just display the result
		is_overflow_digit => '0',
		seg               => seg_result
	);
	
-- Display the overflow flag on the third digit (from the right).
SINGLE_OVF : single_number
	port map (
		number   => "0000",  -- Value is ignored if overflow is '1'
      overflow => ovf,     -- If ALU overflow is '1', this module displays "F"
		is_overflow_digit  => '1',
      seg      => seg_overflow
    );
	
-- Pocess to iterate through seg_mode
seg_mode_switch : process (clk)
begin
	if rising_edge(clk) then
		if (clk_cnt = cnt_max) then
			seg_mode <= seg_mode_new;
			clk_cnt <= 0;
		else
			clk_cnt <= clk_cnt + 1;
		end if;
	end if;
end process;

-- This process selects which digit (anode) is active and routes the appropriate
-- seven-segment pattern to the cathode output
display : process (seg_mode, seg_a, seg_b, seg_overflow, seg_result)
begin
	case seg_mode is
		when 3 =>    -- leftmost digit for PI_a => show PI_a
			PO_an <= "0111";
			PO_seg <= seg_a;
			seg_mode_new <= 2;
		
		when 2 =>    -- 2nd digit from the left => show PI_b
			PO_an <= "1011";
			PO_seg <= seg_b;
			seg_mode_new <= 1;
		
		when 1 =>    -- 3rd digit from left => overflow indicator
			PO_an <= "1101";
			PO_seg <= seg_overflow;
			seg_mode_new <= 0;
		
		when 0 =>    -- rightmost digit for ALU_result => show ALU_result
			PO_an <= "1110";
			PO_seg <= seg_result;
			seg_mode_new <= 3;
			
		when others =>
			-- default case if seg_mode is out of range
			PO_an <= "1111";
			PO_seg <= "11111111";
			seg_mode_new <= 3;
	end case;
end process;
end Behavioral;

